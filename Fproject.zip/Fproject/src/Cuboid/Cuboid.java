/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Cuboid;

import javafx.application.Application;
import javafx.scene.Camera;
import javafx.scene.Group;
import javafx.scene.PerspectiveCamera;
import javafx.scene.Scene;
import javafx.scene.input.KeyEvent;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.shape.Box;
import javafx.scene.transform.Rotate;
import javafx.scene.transform.Transform;

/**
 *
 * @author qianyang
 */
public class Cuboid extends Application{
    private static final int WIDTH = 1400;
    private static final int HEIGHT = 800;
    

    @Override
    public void start(Stage primaryStage) throws Exception {
         Box box = new Box(100,40,60);
      
         SmartGroup group = new SmartGroup();
         group.getChildren().add(box);

         Camera camera = new PerspectiveCamera();
         
         Scene scene = new Scene(group, WIDTH, HEIGHT);
         scene.setFill(Color.SILVER);
         scene.setCamera(camera);
         
         group.translateXProperty().set(WIDTH/2);
         group.translateYProperty().set(HEIGHT/2);
         group.translateZProperty().set(-1000);//set the distance between the obeject and observer
         
         //Transform transform = new Rotate(65,new Point3D(0,1,0)); //add axis to raotate the object
         //box.getTransforms().add(transform);
         
         
         primaryStage.addEventHandler(KeyEvent.KEY_PRESSED, event ->{
                switch (event.getCode())
                {
                     case W://shrink
                         group.translateZProperty().set(box.getTranslateZ()+100);
                         break;
                     case S://zoom
                         group.translateZProperty().set(box.getTranslateZ()-100);
                         break;    
                     case Q://control rotate by x axis
                         group.rotateByX(10);
                         break; 
                     case E://control rotate by x axis
                         group.rotateByX(-10);
                         break; 
                     case Z://control rotate by y axis
                         group.rotateByY(10);
                         break; 
                     case C://control rotate by y axis
                         group.rotateByY(-10);
                         break; 
                }        
         });

         primaryStage.setTitle("dadada");
         primaryStage.setScene(scene);
         primaryStage.show();
    }             
    
        public static void main(String[] args) {
        launch(args);
    }
        class SmartGroup extends Group//before Update,make it easy to rotate a object
        {
            Rotate r;
            Transform t = new Rotate();
            
            void rotateByX(int ang)
            {
                r = new Rotate(ang, Rotate.X_AXIS);
                t = t.createConcatenation(r);
                this.getTransforms().clear();//transform the previous transform
                this.getTransforms().addAll(t);//play the new transform over the previous and upload it back again
            }
            
            void rotateByY(int ang)
            {
                r = new Rotate(ang, Rotate.Y_AXIS);
                t = t.createConcatenation(r);
                this.getTransforms().clear();
                this.getTransforms().addAll(t);
            }
        
        
        }
    
}

