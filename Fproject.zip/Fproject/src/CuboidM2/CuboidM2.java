/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CuboidM2;

import javafx.application.Application;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.scene.Camera;
import javafx.scene.Group;
import javafx.scene.PerspectiveCamera;
import javafx.scene.Scene;
import javafx.scene.input.ScrollEvent;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.shape.Box;
import javafx.scene.transform.Rotate;
import javafx.scene.transform.Transform;

/**
 *
 * @author qianyang
 */
public class CuboidM2 extends Application{

    private static final float WIDTH = 1400;
    private static final float HEIGHT = 800;
    
    private double anchorX, anchorY;//act the anchor points to click and tarck
    private double anchorAngleX = 0;//two other X&Y rotation varibles
    private double anchorAngleY = 0;
    private final DoubleProperty angleX = new SimpleDoubleProperty(0);//rotation angle
    private final DoubleProperty angleY = new SimpleDoubleProperty(0);
    
    @Override
    public void start(Stage primaryStage) throws Exception {
         Box box = new Box(100,20,50);
      
         SmartGroup group = new SmartGroup();
         group.getChildren().add(box);

         Camera camera = new PerspectiveCamera();
         Scene scene = new Scene(group, WIDTH, HEIGHT);
         scene.setFill(Color.SILVER);
         scene.setCamera(camera);
         
         group.translateXProperty().set(WIDTH/2);
         group.translateYProperty().set(HEIGHT/2);//fix the object in milddle of the Screen
         group.translateZProperty().set(-1000);//set the distance between the obeject and observer
         
         initMouseControl(group, scene, primaryStage);
         

         primaryStage.setTitle("dadada");
         primaryStage.setScene(scene);
         primaryStage.show();
    }             
    
        public static void main(String[] args) {
        launch(args);
    }

    private void initMouseControl(SmartGroup group, Scene scene, Stage stage) {
              Rotate xRotate;
              Rotate yRotate;
              group.getTransforms().addAll(
                         xRotate = new Rotate(0,Rotate.X_AXIS),
                         yRotate = new Rotate(0,Rotate.Y_AXIS)
                    );
              xRotate.angleProperty().bind(angleX);
              yRotate.angleProperty().bind(angleY);
              
              scene.setOnMousePressed(event -> {
                     anchorX = event.getSceneX();//the position where you click
                     anchorY = event.getSceneY();
                     anchorAngleX = angleX.get();
                     anchorAngleY = angleY.get();
              });
              
              scene.setOnMouseDragged(event ->{//tarck the mouse key
                   angleX.set(anchorAngleX - (anchorY - event.getSceneY()));//distance tracked in the y axis
                   angleY.set(anchorAngleY + (anchorX - event.getSceneX()));
              });
              
              stage.addEventHandler(ScrollEvent.SCROLL, event ->{
                      double delta = event.getDeltaY();
                      group.translateZProperty().set(group.getTranslateZ() + delta);
    
               });
    }
        
    class SmartGroup extends Group//before Update,make it easy to rotate a object
        {
            Rotate r;
            Transform t = new Rotate();
            
            void rotateByX(int ang)
            {
                r = new Rotate(ang, Rotate.X_AXIS);
                t = t.createConcatenation(r);
                this.getTransforms().clear();//transform the previous transform
                this.getTransforms().addAll(t);//play the new transform over the previous and upload it back again
            }
            
            void rotateByY(int ang)
            {
                r = new Rotate(ang, Rotate.Y_AXIS);
                t = t.createConcatenation(r);
                this.getTransforms().clear();
                this.getTransforms().addAll(t);
            }
        
        
        }
    
}